const db = require('./db');
console.log('✅ typeof db.prepare is:', typeof db.prepare);
